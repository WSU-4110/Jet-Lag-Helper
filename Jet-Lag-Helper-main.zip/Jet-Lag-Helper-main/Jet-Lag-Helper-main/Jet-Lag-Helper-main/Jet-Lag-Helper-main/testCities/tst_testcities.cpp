#include <QtTest>

// add necessary includes here

class testCities : public QObject
{
    Q_OBJECT

public:
    testCities();
    ~testCities();

private slots:
    void test_case1();

};

testCities::testCities()
{

}

testCities::~testCities()
{

}

void testCities::test_case1()
{

}

QTEST_APPLESS_MAIN(testCities)

#include "tst_testcities.moc"
