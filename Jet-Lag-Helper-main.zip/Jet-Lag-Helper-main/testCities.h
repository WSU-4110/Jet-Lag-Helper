#ifndef TESTCITIES_H
#define TESTCITIES_H

#include "city.h"
#include "cities.h"
#include <QtTest/QTest>

class testCities: public QObject
{
    Q_OBJECT;
//public:
    //TestCities();

private slots:
    void init();
    void cityIDtest1();
    void cityIDtest2();
    void cityIDtest3();
    void cityByNametest1();
    void cityByNametest2();
    void cityByNametest3();
};

#endif // TESTCITIES_H
