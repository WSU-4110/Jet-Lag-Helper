#include "testCities.h"

//TestCities::TestCities()

void testCities::init(){

}

void testCities::cityIDtest1(){
    Cities c;
    City city = c.getCityByID(524901);
    QVERIFY(city.debugString() == "Moscow, Russia");

}

void testCities::cityIDtest2(){
    Cities c;
    City city = c.getCityByID(108410);
    QVERIFY(city.debugString() == "Riyadh" "Saudi Arabia");

}

void testCities::cityIDtest3(){
    Cities c;
    City city = c.getCityByID(292223);
    QVERIFY(city.debugString() == "Dubai" "United Arab Emirates");

}

void testCities::cityByNametest1(){
    Cities c;
    City city = c.getCityByName("Toronto");
    QVERIFY(city.debugString() == "Toronto" "Canada");
}

void testCities::cityByNametest2(){
    Cities c;
    City city = c.getCityByName("Rome");
    QVERIFY(city.debugString() == "Rome" "Italy");
}

void testCities::cityByNametest3(){
    Cities c;
    City city = c.getCityByName("Nanjing");
    QVERIFY(city.debugString() == "Nanjing" "China");
}

QTEST_MAIN(testCities);
